env=input("Enter the env: ")

if env=="prd":
    print("DOnt deploy")
elif env=="std":
    print("DOnt")
else:
    print("Deploy")
