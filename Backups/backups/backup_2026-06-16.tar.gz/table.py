choice=input("enter q")




while choice!="q":
            num=int(input("Enter ur num"))
            for i in range(1,11):
                print(f"{num} X {i}={num*i}")
            choice=input("enter q")