# name=input("Enter ur Name: ")

x=50
y=50

z=x/y

print(type(z))